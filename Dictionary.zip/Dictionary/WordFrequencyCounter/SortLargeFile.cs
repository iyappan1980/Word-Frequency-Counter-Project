﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WordFrequencyCounter
{
    class SortLargeFile
    {
        public static ILogger _logger;
        public static void MergeSortTextFile(string inputFilePath, string outputFilePath, long maxLinesInMemory, ILogger logger)
        {
            _logger = logger;
            _logger.Info("Starting Merge Sort of Large text file");
            List<string> tempFiles = SplitAndSortFile(inputFilePath, maxLinesInMemory);
            MergeTempFiles(tempFiles, outputFilePath);

            // Clean up temporary files
            foreach (var file in tempFiles)
            {
                File.Delete(file);
            }
            _logger.Info("Completed sorting Large text file.");
        }


        static List<string> SplitAndSortFile(string inputFilePath, long maxLinesInMemory)
        {
            var tempFilesList = new List<string>();
            using (var reader = new StreamReader(inputFilePath, Encoding.GetEncoding("Windows-1252"), true))
            {
                string line;
                var wordFrequencyList = new List<(string, int)>();
                while ((line = reader.ReadLine()) != null)
                {
                    var item = line.Split(',');
                    wordFrequencyList.Add((item[0], int.Parse(item[1])));

                    if (wordFrequencyList.Count >= maxLinesInMemory)
                    {
                        tempFilesList.Add(SortAndWriteLinesToFile(wordFrequencyList));
                        wordFrequencyList.Clear();
                    }
                }

                if (wordFrequencyList.Any())
                {
                    tempFilesList.Add(SortAndWriteLinesToFile(wordFrequencyList));
                }
            }
            return tempFilesList;
        }

        static string SortAndWriteLinesToFile(List<(string, int)> linesList)
        {
            string tempFilePath = Path.GetTempFileName();
            linesList = linesList
                .OrderByDescending(x => x.Item2)
                .ThenBy(x => x.Item1)
                .ToList();

            using (var writer = new StreamWriter(tempFilePath, false, Encoding.GetEncoding("Windows-1252")))
            {
                foreach (var (word, frequency) in linesList)
                {
                    writer.WriteLine($"{word},{frequency}");
                }
            }

            return tempFilePath;
        }


        static void MergeTempFiles(List<string> tempFiles, string outputFilePath)
        {
            var filereaderList = tempFiles.Select(file => new StreamReader(file, Encoding.GetEncoding("Windows-1252"), true)).ToList();
            var priorityQueue = new SortedSet<(string word, int frequency, int fileNumber)>(
                Comparer<(string word, int frequency, int fileNumber)>.Create((x, y) =>
                {
                    int cmp = y.frequency.CompareTo(x.frequency); // Descending by frequency
                    if (cmp == 0)
                        cmp = x.word.CompareTo(y.word); // Ascending by word
                    if (cmp == 0)
                        cmp = x.fileNumber.CompareTo(y.fileNumber); // Finally by filenumber
                    return cmp;
                })
            );

            for (int i = 0; i < filereaderList.Count; i++)
            {
                var line = filereaderList[i].ReadLine();
                if (line != null)
                {
                    var parts = line.Split(',');
                    priorityQueue.Add((parts[0], int.Parse(parts[1]), i));
                }
            }

            using (var writer = new StreamWriter(outputFilePath, false, Encoding.GetEncoding("Windows-1252")))
            {
                while (priorityQueue.Any())
                {
                    var topItem = priorityQueue.Min;
                    priorityQueue.Remove(topItem); ;

                    writer.WriteLine($"{topItem.word},{topItem.frequency}");

                    var line = filereaderList[topItem.fileNumber].ReadLine();
                    if (line != null)
                    {
                        var parts = line.Split(',');
                        priorityQueue.Add((parts[0], int.Parse(parts[1]), topItem.fileNumber));
                    }
                }
            }

            foreach (var file in filereaderList)
            {
                file.Dispose();
            }
        }
    }
}
