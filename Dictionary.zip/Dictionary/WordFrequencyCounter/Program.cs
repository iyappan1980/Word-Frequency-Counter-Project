﻿
using Dictionary;
using WordFrequencyCounter;

partial class Program
{
    static void Main(string[] args)
    {
        if(args.Length == 2)
        {
            var logger = new FileLogger(GlobalVariable.LogPath);
            WordFrequencyCount objWordFrequencyCount = new WordFrequencyCount(args[0], args[1], logger);
            objWordFrequencyCount.Process();            
        }
        else
        {
            Console.WriteLine("Required arguments: Input file and Output file missing");
        }
        
    }
}