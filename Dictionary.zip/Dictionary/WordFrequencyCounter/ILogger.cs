﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordFrequencyCounter
{
    public enum Level
    {
        Debug =1,
        Info = 2,
        Warning = 3,
        Error = 4
    }

    public interface ILogger : IDisposable
    {
        void Log(string message, Level severity);
        public void Debug(string message);
        public void Info(string message);
        public void Warn(string message);
        public void Error(string message);

        public void Dispose();
    }
    }
