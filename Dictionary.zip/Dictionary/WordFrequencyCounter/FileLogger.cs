﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordFrequencyCounter
{
    public class FileLogger : ILogger
    {
        private readonly StreamWriter _writer;
        private readonly object _streamLock = new();
        public string _filename;

        public FileLogger(string filename)
        {
            _filename = filename;            
            _writer = new StreamWriter(filename);
        }

        private void Flush()
        {
            lock( _streamLock )
            {
                _writer.Flush();
            }
        }

        public void Dispose()
        {
            lock(_streamLock )
            {
                _writer.Flush();
                _writer.Dispose();
            }
        }
        public void Debug(string message)
        {
            Log(message, Level.Debug);
        }
        public void Info(string message)
        {
            Log(message, Level.Info);
        }
        public void Warn(string message)
        {
            Log(message, Level.Warning);
        }

        public void Error(string message)
        {
            Log(message, Level.Error);
        }
        public void Log(string message, Level severity)
        {
            StringBuilder prefix = new StringBuilder();
            switch (severity)
            {
                case Level.Debug:
                    prefix.Append("[Debug] ");
                    break;
                case Level.Info:
                    prefix.Append("[Info] ");
                    break;
                case Level.Warning:
                    prefix.Append("[Warning] ");
                    break;
                case Level.Error:
                    prefix.Append("[Error] ");
                    break;

            }
            var logLine = prefix + DateTime.UtcNow.ToString() + " " + message;
            _writer.WriteLine(logLine);
            Flush();

        }
    }
}
