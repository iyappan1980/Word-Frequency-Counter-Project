﻿using Dictionary;
using System.Collections.Concurrent;
using System.Text;

namespace WordFrequencyCounter
{
    public class WordFrequencyCount : IDisposable
    {
        public WordFrequencyCount(string inputFile, string outputFile, ILogger logger)
        {
            _inputFile = inputFile;
            _outputFile = outputFile;
            FileInfo fileInfo = new FileInfo(GlobalVariable.LogPath);

            if (!fileInfo.Exists)
                Directory.CreateDirectory(fileInfo.Directory.FullName);
            _logger = logger;
            dataItems = new BlockingCollection<string>();
            wordDictionary = new Dictionary<string, int>();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        }

        public void Dispose()
        {
            _logger.Dispose();
            dataItems.Dispose();
        }

        private string _inputFile;
        private string _outputFile;
        private ILogger _logger;

        public BlockingCollection<string> dataItems;
        public Dictionary<string, int> wordDictionary;
        
        int fileCount = 0; // Not locked as only oe instance of SwapDictionaryToFile is running at a time.       
        public void Process()
        {
            if (IsValidInput())
            {
                _logger.Info("Started: Word Frequency Counter");
                Task readerTask = Task.Run(() => FileReader());
                Task processTask = Task.Run(() => ProcessLines());
                Task.WaitAll(readerTask, processTask);
            }
        }

        public bool IsValidInput()
        {
            if (string.IsNullOrEmpty(_inputFile.Trim()))
            {
                _logger.Error("Input file name cannot be empty");
                Console.WriteLine("Input file name cannot be empty");
                return false;
            }
            if (!File.Exists(_inputFile.Trim()))
            {
                _logger.Error("Input file does not exists.");
                Console.WriteLine("Input file does not exists.");
                return false;
            }
            if (Path.GetExtension(_inputFile.Trim()) != ".txt")
            {
                _logger.Error("Input file should be a text file.");
                Console.WriteLine("Input file should be a text file.");
                return false;
            }
            if (Path.GetExtension(_outputFile.Trim()) != ".txt")
            {
                _logger.Error("Output file should be a text file.");
                Console.WriteLine("Input file should be a text file.");
                return false;
            }

            return true;
        }
        public void FileReader()
        {
            try
            {
                _logger.Debug("Started: Reading Input File");
                using (var streamReader = new StreamReader(_inputFile, Encoding.GetEncoding("Windows-1252"), true))
                {
                    while (!streamReader.EndOfStream)
                    {
                        var line = streamReader.ReadLine();
                        if (!string.IsNullOrEmpty(line))
                        {
                            dataItems.Add(line);
                        }
                    }
                }                    
                dataItems.CompleteAdding();
                _logger.Debug("Completed: Reading Input File");
            }
            catch (Exception ex) 
            {
                _logger.Error(ex.ToString());
                Console.WriteLine(ex.ToString()); 
            }
        }        
        public async void ProcessLines()
        {
            var tasks = new List<Task>();
            Task task = null;
            _logger.Debug("Started: Processing Lines");
            while (!dataItems.IsCompleted)
            {                
                string  data = null;
                try
                {
                    data = dataItems.Take().ToLower();

                    if (data != null)
                    {                        
                        var words = data.Split(new[] {' ', '\t', ',', '.','!', '?', ';', ':','-', '"'}, StringSplitOptions.RemoveEmptyEntries);
                        
                        foreach (var word in words)                        
                        {
                            
                            if (wordDictionary.ContainsKey(word))
                            {
                                wordDictionary[word] = wordDictionary[word] + 1;
                            }
                            else
                            {
                                // If Dictionary is more than capacity, swap dictionary to temp file in background and continue processing
                                if (wordDictionary.Count > GlobalVariable.Capacity)
                                {
                                    var newDictionary = new Dictionary<string, int>(wordDictionary);
                                    if (task != null)
                                        Task.WaitAll(task);
                                    task = Task.Run(() => SwapDictionaryToFile(newDictionary)); // Method called asynchronously
                                    wordDictionary.Clear();
                                }
                                wordDictionary.Add(word, 1);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error(ex.ToString());
                    Console.WriteLine(ex.ToString());
                }
            }
            _logger.Debug("Completed: Processing Lines");
            
            if (task != null)
                Task.WaitAll(task);
            var sortedDict = wordDictionary.OrderByDescending(pair => pair.Value).ThenBy(pair => pair.Key).ToDictionary(pair => pair.Key, pair => pair.Value);
            wordDictionary.Clear();
            SwapDictionaryToFile(sortedDict, true); // Method called synchronously
            _logger.Info("Completed: Word Frequency Counter");
        }


        public void SwapDictionaryToFile(Dictionary<string, int> mergeDictionary, bool isOutput = false)
        {            
            if (fileCount == 0) // There is no existing temp files
            {
                string swapFile;
                if (isOutput) // The file created is final output file.
                    swapFile = _outputFile;
                else // First swap file is created.
                    swapFile = GlobalVariable.TempFileStr + fileCount + ".txt";
                
                using (StreamWriter file = new StreamWriter(swapFile, false, Encoding.GetEncoding("Windows-1252")))
                {
                    foreach (var entry in mergeDictionary)
                    {
                        file.WriteLine(entry.Key + "," + entry.Value);
                    }
                }
                fileCount++;
            }
            else
            {
                _logger.Debug("Merging Dictionary With temporary file");
                var swapInputFile = GlobalVariable.TempFileStr + (fileCount-1) + ".txt";
                var swapOutputFile = GlobalVariable.TempFileStr + fileCount + ".txt";
                MergeDictionaryWithTempFile(swapInputFile, swapOutputFile, mergeDictionary);

                File.Delete(swapInputFile);
                if (isOutput)
                {
                    SortLargeFile.MergeSortTextFile(swapOutputFile, _outputFile, GlobalVariable.Capacity, _logger);
                    File.Delete(swapOutputFile);
                    _logger.Debug($"Output file is created successfully {_outputFile}");
                }
                else
                    File.Move(swapOutputFile, swapInputFile);
            }
            mergeDictionary.Clear();            
        }

        public void MergeDictionaryWithTempFile(string swapInputFile, string swapOutputFile, Dictionary<string, int> mergeDictionary)
        {
            using (StreamWriter outputStream = new StreamWriter(Path.Combine(swapOutputFile), false, Encoding.GetEncoding("Windows-1252")))
            {
                using (var streamReader = new StreamReader(swapInputFile, Encoding.GetEncoding("Windows-1252"), true))
                {
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        var entry = line.Split(',', StringSplitOptions.RemoveEmptyEntries);
                        int value;
                        if (mergeDictionary.TryGetValue(entry[0], out value))
                        {
                            var outLine = entry[0] + "," + (Convert.ToInt32(entry[1]) + value);
                            outputStream.WriteLine(outLine);
                            mergeDictionary.Remove(entry[0]);
                        }
                        else
                        {
                            outputStream.WriteLine(entry[0] + "," + entry[1]);
                        }
                    }
                }
                foreach (var entry in mergeDictionary)
                {
                    outputStream.WriteLine(entry.Key + "," + entry.Value);
                }
            }
        }
    }
}
