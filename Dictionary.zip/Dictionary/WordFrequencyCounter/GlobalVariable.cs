﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    public static class GlobalVariable
    {
        public static string LogPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName + "\\Files\\Log.txt";
        public static string TempFileStr = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName + "\\Files\\temp";
        public static long Capacity = 1000000; // Define capacity of Dictionary based on system memory
    }
}
