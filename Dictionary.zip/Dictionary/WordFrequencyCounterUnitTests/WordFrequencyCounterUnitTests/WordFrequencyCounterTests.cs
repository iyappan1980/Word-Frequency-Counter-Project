using Dictionary;
using WordFrequencyCounter;
using Moq;

namespace WordFrequencyCounterUnitTests
{
    public class WordFrequencyCounterTests
    {
        string TestFilePath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName + "\\TestFiles\\";
        private Mock<ILogger> _logger;

        [SetUp]
        public void Setup()
        {
            File.Create("input.txt").Close();
            _logger = new Mock<ILogger>();
        }

        [Test]
        public void TestEmptyInputFileName()
        {
            using (var counter = new WordFrequencyCount("", "out.txt", _logger.Object))
            {
                Assert.IsFalse(counter.IsValidInput());
                _logger.Verify(x => x.Error("Input file name cannot be empty"), Times.Once);

            }
        }

        [Test]
        public void TestInvalidInputFileName()
        {
            using (var counter = new WordFrequencyCount("123.txt", "out.txt", _logger.Object))
            {
                Assert.IsFalse(counter.IsValidInput());
                _logger.Verify(x => x.Error("Input file does not exists."), Times.Once);

            }

        }

        [Test]
        public void TestNonTextInputFileName()
        {
            File.Create("123.json").Close();
            using (var counter = new WordFrequencyCount("123.json", "out.txt", _logger.Object))
            {
                Assert.IsFalse(counter.IsValidInput());
                _logger.Verify(x => x.Error("Input file should be a text file."), Times.Once);

            }
            File.Delete("123.json");
        }

        [Test]
        public void TestNonTextOutputFileName()
        {

            using (var counter = new WordFrequencyCount("input.txt", "out.json", _logger.Object))
            {
                Assert.IsFalse(counter.IsValidInput());
                _logger.Verify(x => x.Error("Output file should be a text file."), Times.Once);

            }
        }

        [Test]
        public void ValidInputOutputFileName()
        {
            using (var counter = new WordFrequencyCount("input.txt", "out.txt", _logger.Object))
            {
                Assert.True(counter.IsValidInput());
            }
        }


        [Test]
        public void ValidateWordFrequencyCounterSimpleTextFile()
        {
            using (var counter = new WordFrequencyCount(TestFilePath + "TestInput1.txt", TestFilePath + "output1.txt", _logger.Object))
            {
                counter.Process();
                var content1 = File.ReadAllText(TestFilePath + "TestOutput1.txt");
                var content2 = File.ReadAllText(TestFilePath + "output1.txt");
                Assert.AreEqual(content1, content2);
            }

        }

        [Test]
        public void ValidateWordFrequencyCounterTextFileSpecialCharacters()
        {
            using (var counter = new WordFrequencyCount(TestFilePath + "TestInput2.txt", TestFilePath + "output2.txt", _logger.Object))
            {
                counter.Process();
                var content1 = File.ReadAllText(TestFilePath + "TestOutput2.txt");
                var content2 = File.ReadAllText(TestFilePath + "output2.txt");
                Assert.AreEqual(content1, content2);
            }
        }

        [Test]
        public void ValidateWordFrequencyCounterBiggerInputFile()
        {
            using (var counter = new WordFrequencyCount(TestFilePath + "TestInput3.txt", TestFilePath + "output3.txt", _logger.Object))
            {
                counter.Process();
                var content1 = File.ReadAllText(TestFilePath + "TestOutput3.txt");
                var content2 = File.ReadAllText(TestFilePath + "output3.txt");
                Assert.AreEqual(content1, content2);
            }
        }

        [Test]
        public void ValidateWordFrequencyCounterWithSwappingToDisk()
        {
            GlobalVariable.Capacity = 50;
            using (var counter = new WordFrequencyCount(TestFilePath + "TestInput4.txt", TestFilePath + "output4.txt", _logger.Object))
            {
                counter.Process();

                var content1 = File.ReadAllText(TestFilePath + "TestOutput4.txt");
                var content2 = File.ReadAllText(TestFilePath + "output4.txt");
                _logger.Verify(x => x.Debug("Merging Dictionary With temporary file"), Times.AtLeastOnce);
                _logger.Verify(x => x.Info("Starting Merge Sort of Large text file"),Times.Once);
                _logger.Verify(x => x.Info("Completed sorting Large text file."), Times.Once);
                Assert.AreEqual(content1, content2);
            }
            GlobalVariable.Capacity = 5000;
        }
    }
}